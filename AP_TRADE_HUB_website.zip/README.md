# AP TRADE HUB Website

Free static website starter for AP TRADE HUB.

## Publish for free
1. Upload `index.html` to GitHub.
2. Create a repository named `ap-trade-hub`.
3. In Settings → Pages, select the main branch and root folder.
4. GitHub will provide the live website address.

Before publishing, replace the placeholder phone number and email in `index.html`.
